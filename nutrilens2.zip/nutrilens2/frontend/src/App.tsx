import { useEffect, useState } from 'react'
import type { FormEvent } from 'react'
import { Link, NavLink, Route, Routes, useNavigate } from 'react-router-dom'
import { ArrowLeftRight, ArrowRight, HeartPulse, Leaf, Menu, Search, Sparkles, Trophy } from 'lucide-react'
import { api } from './api'
import FoodImage from './FoodImage'
import type { Snack } from './types'
import { Challenge, Compare, Dashboard, Explore, GradeBadge, Hacks, SnackCard, SnackDetail, Swaps } from './pages'

function Navbar() {
  const [open, setOpen] = useState(false)
  const links = [
    ['/', 'Home'],
    ['/snacks', 'Explore'],
    ['/compare', 'Compare'],
    ['/swaps', 'Swaps'],
    ['/challenge', 'Challenges'],
    ['/hacks', 'Snack hacks'],
    ['/dashboard', 'Dashboard']
  ]

  return (
    <header className="nav-wrap">
      <nav className="nav">
        <Link to="/" className="brand">
          <span className="brand-mark"><Leaf size={19} /></span>
          <span>NutriLens</span>
        </Link>
        <button className="menu-btn" onClick={() => setOpen(!open)} aria-label="Toggle menu" aria-expanded={open}>
          <Menu />
        </button>
        <div className={`nav-links ${open ? 'open' : ''}`}>
          {links.map(([to, label]) => (
            <NavLink key={to} to={to} end={to === '/'} onClick={() => setOpen(false)}>{label}</NavLink>
          ))}
          <Link to="/snacks" className="nav-cta" onClick={() => setOpen(false)}>
            <Sparkles size={15} /> Analyze a snack
          </Link>
        </div>
      </nav>
    </header>
  )
}

function Landing() {
  const [snacks, setSnacks] = useState<Snack[]>([])
  const [query, setQuery] = useState('')
  const [loadError, setLoadError] = useState(false)
  const navigate = useNavigate()

  useEffect(() => {
    api.get('/snacks')
      .then(response => setSnacks(response.data))
      .catch(() => setLoadError(true))
  }, [])

  const featured = snacks.slice(0, 3)
  const healthy = snacks.filter(snack => snack.grade === 'A').slice(0, 3)
  const heroSnack = snacks.find(snack => snack.name === 'Greek Yogurt & Fruit')
  const submit = (event: FormEvent) => {
    event.preventDefault()
    navigate(`/snacks${query ? `?q=${encodeURIComponent(query)}` : ''}`)
  }

  return (
    <>
      <section className="hero">
        <div className="hero-copy">
          <span className="kicker"><Sparkles size={14} /> A clearer lens on what you eat</span>
          <h1>Snack smarter.<br /><em>Swap better.</em></h1>
          <p>Explore everyday food with clear nutrition context, thoughtful comparisons, and practical swaps.</p>
          <form className="hero-search" onSubmit={submit}>
            <Search size={20} />
            <input value={query} onChange={event => setQuery(event.target.value)} placeholder="Search potato chips, soda, samosa..." />
            <button aria-label="Search"><ArrowRight size={20} /></button>
          </form>
          <div className="hero-actions">
            <Link className="btn primary" to="/snacks">Explore snacks</Link>
            <Link className="btn secondary" to="/swaps">Find a swap</Link>
          </div>
        </div>
        <div className="hero-visual">
          <div className="hero-image-frame">
            <FoodImage name="Greek Yogurt & Fruit" alt="Glass jars of yogurt topped with fresh strawberries" className="hero-photo" />
            <div className="hero-image-caption">
              <div><span>FOOD SPOTLIGHT</span><strong>Greek Yogurt & Fruit</strong></div>
              {heroSnack && <span className="hero-food-value">{heroSnack.calories} kcal <small>/ {heroSnack.serving_size}</small></span>}
            </div>
          </div>
        </div>
      </section>

      <section className="stats-strip" aria-label="NutriLens at a glance">
        <div><strong>{loadError ? '—' : snacks.length}</strong><span>Food profiles</span></div>
        <div><strong>{snacks.length ? new Set(snacks.map(snack => snack.category)).size : '—'}</strong><span>Categories explored</span></div>
        <div><strong>A–E</strong><span>Simple nutrition grades</span></div>
        <div><strong>7 days</strong><span>Weekly challenge</span></div>
      </section>

      <section className="section">
        <div className="section-heading">
          <div><span className="eyebrow">The snack library</span><h2>Explore the everyday</h2></div>
          <Link to="/snacks">Browse all <ArrowRight size={16} /></Link>
        </div>
        {loadError
          ? <div className="empty-state"><h3>Snack profiles couldn’t load</h3><p>Please try again in a moment.</p></div>
          : featured.length
            ? <div className="card-grid">{featured.map(snack => <SnackCard key={snack.id} snack={snack} />)}</div>
            : <div className="card-grid" aria-label="Loading snack profiles"><div className="loading">Loading food profiles...</div></div>}
      </section>

      <section className="section split-section">
        <div className="section-copy">
          <span className="kicker">Your better basket</span>
          <h2>Little swaps.<br />Real differences.</h2>
          <p>Compare calories, sugar, sodium and protein before you choose.</p>
          <Link className="btn dark" to="/compare">Compare snacks</Link>
        </div>
        <div className="swap-preview">
          {healthy.length
            ? healthy.map((snack, index) => (
              <div className="swap-preview-row" key={snack.id}>
                <span>{String(index + 1).padStart(2, '0')}</span>
                <FoodImage name={snack.name} alt={snack.name} />
                <div><strong>{snack.name}</strong><small>{snack.calories} kcal • Grade {snack.grade}</small></div>
                <GradeBadge grade={snack.grade} />
              </div>
            ))
            : <div className="empty-state compact-empty"><Leaf /><h3>Your next discovery starts here</h3><p>Browse snack profiles to see nutrition details.</p></div>}
        </div>
      </section>

      <section className="section">
        <div className="section-heading centered"><div><span className="eyebrow">How it works</span><h2>A smarter snack in three steps</h2></div></div>
        <div className="steps">
          <div><span>01</span><Search /><h3>Find it</h3><p>Search or browse popular snacks.</p></div>
          <div><span>02</span><ArrowLeftRight /><h3>Compare it</h3><p>See the nutrition trade-offs clearly.</p></div>
          <div><span>03</span><HeartPulse /><h3>Swap it</h3><p>Track a choice that feels better for you.</p></div>
        </div>
      </section>

      <section className="challenge-banner">
        <div><span className="kicker"><Trophy size={14} /> Weekly challenge</span><h2>Seven days. Seven mindful swaps.</h2></div>
        <Link className="btn pale" to="/challenge">Explore the challenge <ArrowRight size={16} /></Link>
      </section>
    </>
  )
}

function Footer() {
  return (
    <footer className="footer">
      <div className="brand"><span className="brand-mark"><Leaf size={19} /></span><span>NutriLens</span></div>
      <p>Nutrition context for curious snackers. Not medical advice.</p>
      <Link to="/hacks">Hostel snack hacks</Link>
    </footer>
  )
}

export default function App() {
  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/snacks" element={<Explore />} />
        <Route path="/snacks/:id" element={<SnackDetail />} />
        <Route path="/swaps" element={<Swaps />} />
        <Route path="/compare" element={<Compare />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/challenge" element={<Challenge />} />
        <Route path="/hacks" element={<Hacks />} />
      </Routes>
      <Footer />
    </>
  )
}
