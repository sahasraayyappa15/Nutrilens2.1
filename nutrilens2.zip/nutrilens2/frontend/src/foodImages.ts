export type FoodImageAsset = {
  src: string
  source: string
  credit: string
  license?: string
}

const unsplash = (id: string): FoodImageAsset => ({
  src: `https://images.unsplash.com/${id}?auto=format&fit=crop&w=960&q=85`,
  source: 'https://unsplash.com',
  credit: 'Unsplash'
})

const commons = (file: string, credit: string, license: string): FoodImageAsset => ({
  src: `https://thumb.wikimedia.org/wikipedia/commons/thumb/${file}`,
  source: `https://commons.wikimedia.org/wiki/File:${file.split('/')[2]}`,
  credit,
  license
})

export const foodImages: Record<string, FoodImageAsset> = {
  'Apple': unsplash('photo-1560806887-1e4cd0b6cbd6'),
  'Baked Soya Crisps': commons(
    '2/2a/Kripik_kedelai.jpg/500px-Kripik_kedelai.jpg',
    'Andowardhana',
    'CC BY-SA 4.0'
  ),
  'Chocolate Biscuit': commons(
    '9/93/McVitie%27s_chocolate_digestive_biscuit.jpg/500px-McVitie%27s_chocolate_digestive_biscuit.jpg',
    'pic_p_ter',
    'Public domain'
  ),
  'Cold Coffee': unsplash('photo-1461023058943-07fcbe16d735'),
  'Fruit Chaat': commons(
    'e/eb/Fruit_Chaat.jpg/500px-Fruit_Chaat.jpg',
    'Delhifoodwalks',
    'CC BY-SA 4.0'
  ),
  'Greek Yogurt & Fruit': unsplash('photo-1488477181946-6428a0291777'),
  'Popcorn': unsplash('photo-1585647347483-22b66260dfff'),
  'Potato Chips': commons(
    '4/45/073_Potato_chips%2C_Sanok.JPG/500px-073_Potato_chips%2C_Sanok.JPG',
    'Silar',
    'CC BY-SA 3.0'
  ),
  'Roasted Chana': commons(
    '5/58/Hot_leblebi_-_salty_leblebi.jpg/500px-Hot_leblebi_-_salty_leblebi.jpg',
    'E4024',
    'CC BY-SA 4.0'
  ),
  'Roasted Makhana': commons(
    '1/12/Makhana_%28Foxnut%29_roasted_with_masala_and_ghee.jpg/500px-Makhana_%28Foxnut%29_roasted_with_masala_and_ghee.jpg',
    'FacetsOfNonStickPans',
    'CC BY-SA 4.0'
  ),
  'Samosa': unsplash('photo-1601050690597-df0568f70950'),
  'Sugary Soda': commons(
    '1/10/Glass_cola.jpg/500px-Glass_cola.jpg',
    'pic_p_ter',
    'Public domain'
  ),
  'Peanut Banana Bites': commons(
    '3/3a/Healthy_Snacking.JPG/500px-Healthy_Snacking.JPG',
    'Papathanasiouk',
    'CC BY-SA 3.0'
  ),
  'Masala Makhana Cup': commons(
    '1/12/Makhana_%28Foxnut%29_roasted_with_masala_and_ghee.jpg/500px-Makhana_%28Foxnut%29_roasted_with_masala_and_ghee.jpg',
    'FacetsOfNonStickPans',
    'CC BY-SA 4.0'
  ),
  'Overnight Yogurt Jar': unsplash('photo-1488477181946-6428a0291777'),
  'Quick Fruit Chaat': commons(
    'e/eb/Fruit_Chaat.jpg/500px-Fruit_Chaat.jpg',
    'Delhifoodwalks',
    'CC BY-SA 4.0'
  ),
  'Chana Salad': commons(
    '5/56/Autumn_Chickpea_Salad_%283986173540%29.jpg/500px-Autumn_Chickpea_Salad_%283986173540%29.jpg',
    'Vegan Feast Catering',
    'CC BY 2.0'
  )
}
