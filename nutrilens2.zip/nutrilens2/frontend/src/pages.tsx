import { useEffect, useState } from 'react'
import { Link, useParams, useSearchParams } from 'react-router-dom'
import { Bar } from 'react-chartjs-2'
import { BarElement, CategoryScale, Chart as ChartJS, Legend, LinearScale, Tooltip } from 'chart.js'
import { ArrowLeftRight, Bike, Clock3, Footprints, Leaf, Search, Trophy, Zap } from 'lucide-react'
import { api } from './api'
import FoodImage from './FoodImage'
import type { Snack, SwapLog } from './types'

type SnackHack = {
  id: number
  name: string
  image_url: string
  ingredients: string
  preparation: string
  minutes: number
  convenience: string
}

ChartJS.register(BarElement, CategoryScale, LinearScale, Tooltip, Legend)

const gradeClass: Record<string, string> = { A:'grade-a', B:'grade-b', C:'grade-c', D:'grade-d', E:'grade-e' }
export function GradeBadge({grade}:{grade:string}) { return <span className={`grade ${gradeClass[grade] || ''}`}>{grade}</span> }

export function SnackCard({snack}:{snack:Snack}) {
  return <article className="snack-card">
    <Link to={`/snacks/${snack.id}`} className="snack-image"><FoodImage name={snack.name} alt={snack.name}/><GradeBadge grade={snack.grade}/></Link>
    <div className="snack-card-body"><span className="eyebrow">{snack.category}</span><h3><Link to={`/snacks/${snack.id}`}>{snack.name}</Link></h3><p>{snack.description}</p>
      <div className="snack-meta"><strong>{snack.calories}</strong> kcal • {snack.protein}g protein</div>
      <div className="card-actions"><Link to={`/snacks/${snack.id}`} className="text-link">View details →</Link><Link to={`/swaps?snack=${snack.id}`} className="text-link accent">Find swap</Link></div>
    </div>
  </article>
}

export function Explore() {
  const [params] = useSearchParams()
  const [snacks,setSnacks]=useState<Snack[]>([])
  const [query,setQuery]=useState(params.get('q')||'')
  const [category,setCategory]=useState('All Snacks')
  const [sort,setSort]=useState('name')
  const [loading,setLoading]=useState(true)
  const [loadError,setLoadError]=useState(false)
  useEffect(()=>{
    setLoading(true)
    setLoadError(false)
    const timer=window.setTimeout(()=>{
      const request=query ? api.get('/snacks/search',{params:{q:query}}) : api.get('/snacks',{params:{category,sort}})
      request.then(r=>setSnacks(r.data)).catch(()=>{setSnacks([]);setLoadError(true)}).finally(()=>setLoading(false))
    },250)
    return ()=>window.clearTimeout(timer)
  },[query,category,sort])
  const chips=['All Snacks','Packaged Snacks','Street Food','Beverages','Sweet Snacks','Healthy Snacks']
  return <main className="page">
    <div className="page-header"><div><span className="eyebrow">Snack library</span><h1>Explore snacks</h1><p>Search by name and compare a fair 100g serving.</p></div><div className="search-box"><Search size={18}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search snacks..."/></div></div>
    <div className="filter-row"><div className="chips">{chips.map(chip=><button key={chip} className={category===chip?'active':''} onClick={()=>{setCategory(chip);setQuery('')}}>{chip}</button>)}</div><select value={sort} onChange={e=>setSort(e.target.value)}><option value="name">Alphabetical</option><option value="calories">Lowest calories</option><option value="protein">Highest protein</option><option value="health">Healthiest grade</option></select></div>
    {loadError?<div className="empty-state"><h3>Snack profiles couldn’t load</h3><p>Check your connection and try again.</p></div>:loading?<div className="loading">Finding snack profiles...</div>:snacks.length?<div className="card-grid">{snacks.map(s=><SnackCard key={s.id} snack={s}/>)}</div>:<div className="empty-state"><Search/><h3>No snacks found</h3><p>Try another search or category.</p></div>}
  </main>
}

export function SnackDetail() {
  const {id}=useParams(); const [snack,setSnack]=useState<Snack|null>(null); const [alternatives,setAlternatives]=useState<Snack[]>([])
  const [loading,setLoading]=useState(true); const [loadError,setLoadError]=useState(false);const [alternativesError,setAlternativesError]=useState(false)
  useEffect(()=>{
    let active=true
    setLoading(true);setLoadError(false);setSnack(null)
    api.get(`/snacks/${id}`).then(r=>{if(active)setSnack(r.data)}).catch(()=>{if(active)setLoadError(true)}).finally(()=>{if(active)setLoading(false)})
    setAlternativesError(false)
    api.get(`/swaps/${id}`).then(r=>{if(active)setAlternatives(r.data)}).catch(()=>{if(active){setAlternatives([]);setAlternativesError(true)}})
    return ()=>{active=false}
  },[id])
  if(loading)return <main className="page"><div className="loading">Loading nutrition...</div></main>
  if(loadError||!snack)return <main className="page"><div className="empty-state"><h3>Nutrition profile unavailable</h3><p>This snack could not be loaded. Return to the snack library and try again.</p><Link className="btn primary" to="/snacks">Back to snacks</Link></div></main>
  return <main className="page detail-page">
    <Link className="back-link" to="/snacks">← Back to snacks</Link>
    <section className="detail-hero"><div className="detail-image"><FoodImage name={snack.name} alt={snack.name}/><GradeBadge grade={snack.grade}/></div><div className="detail-copy"><span className="eyebrow">{snack.category} • {snack.serving_size} serving</span><h1>{snack.name}</h1><p>{snack.description}</p><div className="detail-actions"><Link className="btn primary" to={`/compare?left=${snack.id}`}>Compare</Link><Link className="btn dark" to={`/swaps?snack=${snack.id}`}>Find healthier swap</Link></div></div></section>
    <section className="nutrition-grid">{[['Calories',snack.calories,'kcal'],['Protein',snack.protein,'g'],['Carbs',snack.carbohydrates,'g'],['Total fat',snack.total_fat,'g'],['Saturated fat',snack.saturated_fat,'g'],['Sugar',snack.sugar,'g'],['Fiber',snack.fiber,'g'],['Sodium',snack.sodium,'mg']].map(([label,value,unit])=><div className="nutrient-card" key={String(label)}><span>{label}</span><strong>{value}<small>{unit}</small></strong></div>)}</section>
    <section className="detail-info-grid"><div className="panel"><span className="eyebrow">Why this grade?</span><h2>Health grade {snack.grade}</h2><ul className="reason-list">{snack.reasons.map(r=><li><Leaf size={16}/>{r}</li>)}</ul></div><div className="panel"><span className="eyebrow">Ingredients</span><h2>What’s inside</h2><p>{snack.ingredients}</p><div className="serving-note">Standardized to {snack.serving_size} for fair comparison.</div></div></section>
    <section className="section"><div className="section-heading"><div><span className="eyebrow">Smarter choices</span><h2>Recommended alternatives</h2></div></div>{alternativesError?<p className="inline-error">Alternatives couldn’t load. Please try again later.</p>:alternatives.length?<div className="card-grid">{alternatives.map(s=><SnackCard key={s.id} snack={s}/>)}</div>:<p className="muted">No alternatives are available for this snack yet.</p>}</section>
    <section className="energy-panel"><div><Zap/><span>Energy reference</span><h2>~{Math.round(snack.calories/6)} min walking</h2><p>Approximate informational estimate. Energy needs and activity vary between people.</p></div><div className="energy-icons"><span><Footprints/><strong>{Math.round(snack.calories/6)}</strong><small>Walking min</small></span><span><Bike/><strong>{Math.round(snack.calories/8)}</strong><small>Cycling min</small></span><span><Zap/><strong>{Math.round(snack.calories/10)}</strong><small>Jogging min</small></span></div></section>
  </main>
}

export function Swaps(){
  const [params]=useSearchParams();const [snacks,setSnacks]=useState<Snack[]>([]);const [selected,setSelected]=useState(params.get('snack')||'');const [recommendations,setRecommendations]=useState<Snack[]>([])
  const [loadError,setLoadError]=useState(false);const [actionMessage,setActionMessage]=useState('');const [recommendationsLoading,setRecommendationsLoading]=useState(false)
  useEffect(()=>{api.get('/snacks').then(r=>setSnacks(r.data)).catch(()=>setLoadError(true))},[])
  useEffect(()=>{let active=true;setActionMessage('');if(selected){setRecommendationsLoading(true);api.get(`/swaps/${selected}`).then(r=>{if(active)setRecommendations(r.data)}).catch(()=>{if(active)setLoadError(true)}).finally(()=>{if(active)setRecommendationsLoading(false)})}else{setRecommendations([]);setRecommendationsLoading(false)}return()=>{active=false}},[selected])
  const logSwap=async(s:Snack)=>{try{await api.post('/swaps/logs',{original_snack_id:Number(selected),alternative_snack_id:s.id});setActionMessage(`${s.name} swap saved to your dashboard.`)}catch{setActionMessage('This swap could not be saved. Please try again.')}}
  return <main className="page"><div className="page-header"><div><span className="eyebrow">Swap recommender</span><h1>Your smarter swap is waiting.</h1><p>Choose your usual snack to see sensible alternatives.</p></div></div>
    <div className="swap-builder"><label>My current snack<select value={selected} onChange={e=>setSelected(e.target.value)}><option value="">Choose a snack</option>{snacks.map(s=><option value={s.id} key={s.id}>{s.name}</option>)}</select></label><ArrowLeftRight/></div>
    {loadError?<div className="empty-state"><h3>Swap recommendations unavailable</h3><p>We couldn’t load the snack data. Please try again later.</p></div>:selected&&recommendationsLoading?<div className="loading">Finding thoughtful alternatives...</div>:selected&&recommendations.length?<div className="card-grid">{recommendations.map(s=>{const d=s.differences!;return <article className="swap-card" key={s.id}><div className="swap-card-image"><FoodImage name={s.name} alt={s.name}/><GradeBadge grade={s.grade}/></div><div className="swap-card-body"><span className="eyebrow">{s.category}</span><h3>{s.name}</h3><p>{s.benefit}</p><div className="difference-grid"><div><span>Calories</span><strong className={d.calories<0?'good':'warm'}>{d.calories>0?'+' :''}{d.calories}</strong></div><div><span>Sugar</span><strong className={d.sugar<0?'good':'warm'}>{d.sugar>0?'+' :''}{d.sugar}g</strong></div><div><span>Sodium</span><strong className={d.sodium<0?'good':'warm'}>{d.sodium>0?'+' :''}{d.sodium}mg</strong></div><div><span>Protein</span><strong className={d.protein>0?'good':'warm'}>{d.protein>0?'+' :''}{d.protein}g</strong></div></div><button className="btn primary full" onClick={()=>logSwap(s)}>Log this swap</button></div></article>})}</div>:selected?<div className="empty-state"><h3>No alternatives found</h3><p>Try choosing another snack.</p></div>:<div className="empty-state"><Leaf/><h3>Choose a snack to begin</h3><p>Your recommendations will appear here.</p></div>}
    {actionMessage&&<p className={actionMessage.startsWith('This')?'inline-error':'inline-success'} role="status">{actionMessage}</p>}
  </main>
}

export function Compare(){
  const [params]=useSearchParams();const [snacks,setSnacks]=useState<Snack[]>([]);const [leftId,setLeftId]=useState(params.get('left')||'');const [rightId,setRightId]=useState(params.get('right')||'')
  const [loadError,setLoadError]=useState(false)
  useEffect(()=>{api.get('/snacks').then(r=>setSnacks(r.data)).catch(()=>setLoadError(true))},[])
  const left=snacks.find(s=>String(s.id)===leftId),right=snacks.find(s=>String(s.id)===rightId)
  const chartData={labels:['Calories','Protein','Sugar','Sodium / 10'],datasets:[{label:left?.name||'Snack A',data:left?[left.calories,left.protein,left.sugar,left.sodium/10]:[],backgroundColor:'#7d708f'},{label:right?.name||'Snack B',data:right?[right.calories,right.protein,right.sugar,right.sodium/10]:[],backgroundColor:'#df9a8c'}]}
  const summary=left&&right?`Compared with ${left.name}, ${right.name} has ${right.calories===left.calories?'the same number of':right.calories<left.calories?'fewer':'more'} calories, ${right.sugar===left.sugar?'the same amount of':right.sugar<left.sugar?'less':'more'} sugar and ${right.protein===left.protein?'the same amount of':right.protein>left.protein?'more':'less'} protein.`:'Choose two snacks to calculate a live comparison.'
  return <main className="page"><div className="page-header"><div><span className="eyebrow">Side-by-side</span><h1>Compare snacks</h1><p>Values are shown per the listed standardized serving.</p></div></div>
    <div className="compare-selectors"><label>Original snack<select value={leftId} onChange={e=>setLeftId(e.target.value)}><option value="">Choose</option>{snacks.map(s=><option value={s.id} key={s.id}>{s.name}</option>)}</select></label><ArrowLeftRight/><label>Alternative snack<select value={rightId} onChange={e=>setRightId(e.target.value)}><option value="">Choose</option>{snacks.map(s=><option value={s.id} key={s.id}>{s.name}</option>)}</select></label></div>
    {loadError&&<p className="inline-error">Snack data couldn’t load, so a comparison can’t be calculated yet.</p>}
    {left&&right?<><section className="compare-cards">{[left,right].map((s,i)=><article key={s.id} className="compare-card"><FoodImage name={s.name} alt={s.name}/><div><span>{i?'Alternative':'Original'}</span><h2>{s.name}</h2><GradeBadge grade={s.grade}/></div></article>)}</section><div className="comparison-layout"><div className="panel chart-panel"><h2>Nutritional snapshot</h2><Bar data={chartData} options={{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom'}}}}/></div><div className="panel"><h2>Nutrition table</h2><table><thead><tr><th>Metric</th><th>{left.name}</th><th>{right.name}</th></tr></thead><tbody>{[['Calories',left.calories,right.calories,'kcal'],['Protein',left.protein,right.protein,'g'],['Carbohydrates',left.carbohydrates,right.carbohydrates,'g'],['Sugar',left.sugar,right.sugar,'g'],['Saturated fat',left.saturated_fat,right.saturated_fat,'g'],['Fiber',left.fiber,right.fiber,'g'],['Sodium',left.sodium,right.sodium,'mg']].map(([name,a,b,unit])=><tr key={String(name)}><td>{name}</td><td>{a}{unit}</td><td className={Number(b)<Number(a)?'good':''}>{b}{unit}</td></tr>)}</tbody></table></div></div><div className="comparison-summary"><Leaf/><div><span>Swap summary</span><strong>{summary}</strong></div></div></>:<div className="empty-state"><ArrowLeftRight/><h3>Choose two snacks</h3></div>}
  </main>
}

export function Dashboard(){
  type Activity = { created_at:string; original_calories:number; alternative_calories:number }
  type Stats = { total:number; calories:number; sugar:number; sodium:number; protein:number; activity:Activity[] }
  const [logs,setLogs]=useState<SwapLog[]>([])
  const [stats,setStats]=useState<Stats>({total:0,calories:0,sugar:0,sodium:0,protein:0,activity:[]})
  const [loading,setLoading]=useState(true);const [loadError,setLoadError]=useState(false);const [actionError,setActionError]=useState('')
  const refresh=async()=>{try{const [logResponse,statsResponse]=await Promise.all([api.get('/swaps/logs'),api.get('/swaps/stats')]);setLogs(logResponse.data);setStats(statsResponse.data);setLoadError(false)}catch{setLoadError(true)}finally{setLoading(false)}}
  useEffect(()=>{void refresh()},[])
  const remove=async(id:number)=>{try{await api.delete(`/swaps/logs/${id}`);setActionError('');await refresh()}catch{setActionError('The swap could not be deleted. Please try again.')}}
  const recentActivity=stats.activity.slice(-7).reverse()
  const chartData={labels:recentActivity.map(row=>new Date(row.created_at).toLocaleDateString(undefined,{month:'short',day:'numeric'})),datasets:[{label:'Calories reduced (+) / increased (-)',data:recentActivity.map(row=>row.original_calories-row.alternative_calories),backgroundColor:'#807391',borderRadius:8}]}
  return <main className="page dashboard-page">
    <section className="dashboard-welcome"><div><span className="eyebrow">Your nutrition snapshot</span><h1>Small choices, in perspective.</h1><p>Review the snack swaps you’ve actually logged and what changed.</p></div><div className="dashboard-quick-actions"><Link className="btn primary" to="/swaps">Log a swap</Link><Link className="btn secondary" to="/snacks">Explore snacks</Link></div></section>
    {loadError?<div className="empty-state"><h3>Dashboard data couldn’t load</h3><p>Your saved activity is still stored. Try refreshing the page.</p></div>:loading?<div className="loading">Loading your saved activity...</div>:<>
      <section className="dashboard-stats">
        <div><span>Logged swaps</span><strong>{stats.total}</strong></div>
        <div><span>Calorie difference</span><strong>{stats.calories.toFixed(0)} kcal</strong><small>positive means fewer calories across logged swaps</small></div>
        <div><span>Sugar difference</span><strong>{stats.sugar.toFixed(1)} g</strong><small>positive means less sugar</small></div>
        <div><span>Sodium difference</span><strong>{stats.sodium.toFixed(0)} mg</strong><small>positive means less sodium</small></div>
      </section>
      <div className="dashboard-grid">
        <section className="panel chart-panel">
          <div className="panel-heading"><div><span className="eyebrow">Your activity</span><h2>Calorie difference by swap</h2></div></div>
          {recentActivity.length
            ? <Bar data={chartData} options={{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true}}}}/>
            : <div className="chart-empty"><Leaf/><h3>Your chart starts with your first swap</h3><p>Logged snack choices will appear here.</p><Link className="text-link accent" to="/swaps">Find a swap →</Link></div>}
        </section>
        <section className="panel recent-panel">
          <div className="panel-heading"><div><span className="eyebrow">Saved history</span><h2>Recent swaps</h2></div><Link to="/swaps" className="text-link accent">Add one</Link></div>
          {logs.length?logs.map(log=><div className="recent-row" key={log.id}>
            <div className="recent-food-pair"><FoodImage name={log.original_name} alt={log.original_name}/><span className="recent-arrow">→</span><FoodImage name={log.alternative_name} alt={log.alternative_name}/><div><strong>{log.original_name}</strong><span>to {log.alternative_name}</span><small>{new Date(log.created_at).toLocaleDateString()}</small></div></div>
            <button onClick={()=>remove(log.id)} aria-label={`Delete ${log.original_name} to ${log.alternative_name} swap`}>Delete</button>
          </div>):<div className="history-empty"><p>No swaps logged yet.</p><Link className="btn secondary" to="/swaps">Find your first swap</Link></div>}
          {actionError&&<p className="inline-error" role="alert">{actionError}</p>}
        </section>
      </div>
      <section className="dashboard-links"><Link to="/compare"><ArrowLeftRight/><span><strong>Compare food</strong><small>See nutrition side by side</small></span></Link><Link to="/hacks"><Leaf/><span><strong>Snack hacks</strong><small>Quick, practical ideas</small></span></Link><Link to="/challenge"><Trophy/><span><strong>Weekly challenge</strong><small>Track a seven-day goal</small></span></Link></section>
    </>}
  </main>
}

export function Challenge(){
  const [progress,setProgress]=useState<{day:number;completed:number}[]>([]);const [tasks,setTasks]=useState<{day:number;title:string}[]>([])
  const [loading,setLoading]=useState(true);const [loadError,setLoadError]=useState(false);const [actionError,setActionError]=useState('')
  useEffect(()=>{Promise.all([api.get('/challenges'),api.get('/challenges/progress')]).then(([taskResponse,progressResponse])=>{setTasks(taskResponse.data);setProgress(progressResponse.data)}).catch(()=>setLoadError(true)).finally(()=>setLoading(false))},[])
  const toggle=async(day:number,completed:number)=>{try{const r=await api.post('/challenges/progress',{day,completed:!completed});setProgress(prev=>prev.map(p=>p.day===day?r.data:p));setActionError('')}catch{setActionError('Challenge progress could not be saved. Please try again.')}}
  const done=progress.filter(p=>p.completed).length
  return <main className="page"><div className="challenge-hero"><div><span className="kicker"><Trophy size={14}/> 7-day challenge</span><h1>Small swaps, big week.</h1><p>Complete one healthy snack choice each day.</p></div><div className="progress-ring" style={{'--progress':`${done/7*360}deg`} as React.CSSProperties}><strong>{done}/7</strong><span>complete</span></div></div><div className="challenge-progress"><div><span style={{width:`${done/7*100}%`}}/></div><strong>{Math.round(done/7*100)}%</strong></div>
    {loadError?<div className="empty-state"><h3>Challenge data couldn’t load</h3><p>Your progress couldn’t be retrieved. Please refresh and try again.</p></div>:loading?<div className="loading">Loading challenge progress...</div>:tasks.length?<div className="challenge-grid">{tasks.map(task=>{const state=progress.find(p=>p.day===task.day);const completed=!!state?.completed;return <button className={`day-card ${completed?'completed':''}`} key={task.day} onClick={()=>toggle(task.day,state?.completed||0)}><span className="day-number">Day {task.day}</span><div className="check">{completed?'✓':'+'}</div><h3>{task.title}</h3><small>{completed?'Completed':'Mark complete'}</small></button>})}</div>:<div className="empty-state"><h3>No challenge tasks are available</h3></div>}{actionError&&<p className="inline-error" role="alert">{actionError}</p>}{done===7&&<div className="completion"><Trophy/><div><span>Challenge complete</span><h2>You built a full week of mindful swaps.</h2></div></div>}
  </main>
}

export function Hacks(){
  const [hacks,setHacks]=useState<SnackHack[]>([]);const [loading,setLoading]=useState(true);const [loadError,setLoadError]=useState(false)
  useEffect(()=>{api.get('/snack-hacks').then(r=>setHacks(r.data)).catch(()=>setLoadError(true)).finally(()=>setLoading(false))},[])
  return <main className="page"><div className="page-header"><div><span className="eyebrow">Hostel friendly</span><h1>Snack hacks</h1><p>Low-cost, minimal-prep ideas for busy college days.</p></div></div>{loadError?<div className="empty-state"><h3>Snack ideas couldn’t load</h3><p>Please try again in a moment.</p></div>:loading?<div className="loading">Loading snack ideas...</div>:hacks.length?<div className="hacks-grid">{hacks.map(hack=><article className="hack-card" key={hack.id}><FoodImage name={hack.name} alt={hack.name}/><div><span className="eyebrow"><Clock3 size={14}/> {hack.minutes} min</span><h2>{hack.name}</h2><p><strong>Ingredients:</strong> {hack.ingredients}</p><p><strong>Steps:</strong> {hack.preparation}</p><div className="why"><Leaf size={16}/>{hack.convenience}</div></div></article>)}</div>:<div className="empty-state"><h3>No snack ideas yet</h3></div>}</main>
}
