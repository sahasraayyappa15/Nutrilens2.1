import { ImageOff } from 'lucide-react'
import { useState } from 'react'
import { foodImages } from './foodImages'

type Props = {
  name: string
  alt?: string
  className?: string
}

export default function FoodImage({ name, alt, className = '' }: Props) {
  const [failed, setFailed] = useState(false)
  const asset = foodImages[name]
  const accessibleName = alt || name

  if (!asset || failed) {
    return (
      <span className={`food-image-fallback ${className}`} role="img" aria-label={`${accessibleName} image unavailable`}>
        <ImageOff size={22} />
        <span>Image unavailable</span>
      </span>
    )
  }

  return (
    <img
      className={className}
      src={asset.src}
      alt={accessibleName}
      title={`Photo: ${asset.credit}${asset.license ? ` · ${asset.license}` : ''} · Source: ${asset.source}`}
      loading="lazy"
      onError={() => setFailed(true)}
    />
  )
}
