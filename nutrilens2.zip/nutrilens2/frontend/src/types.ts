export type Snack = {
  id: number
  name: string
  category: string
  description: string
  image_url: string
  calories: number
  protein: number
  carbohydrates: number
  total_fat: number
  saturated_fat: number
  sugar: number
  fiber: number
  sodium: number
  serving_size: string
  ingredients: string
  grade: string
  reasons: string[]
  differences?: {
    calories: number
    sugar: number
    sodium: number
    protein: number
  }
  benefit?: string
}

export type SwapLog = {
  id: number
  original_snack_id: number
  alternative_snack_id: number
  created_at: string
  original_name: string
  alternative_name: string
  original_calories: number
  alternative_calories: number
  original_sugar: number
  alternative_sugar: number
  original_sodium: number
  alternative_sodium: number
  original_protein: number
  alternative_protein: number
}
