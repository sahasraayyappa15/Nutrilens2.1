import { db } from './database'

export function seedDatabase() {
  const count = db.prepare('SELECT COUNT(*) AS count FROM snacks').get() as { count: number }
  if (count.count) return

  const snacks = [
    ['Potato Chips','Packaged Snacks','Thin, crisp salted potato chips.', 'https://images.unsplash.com/photo-1566478989037-eec170784d0b',536,7,53,34,11,1,4,528,'100g','Potatoes, oil, salt'],
    ['Chocolate Biscuit','Sweet Snacks','Popular sweet biscuit with a chocolate coating.', 'https://images.unsplash.com/photo-1499636136210-6f4ee915583e',480,6,67,21,10,25,3,310,'100g','Wheat flour, sugar, cocoa, vegetable oil'],
    ['Samosa','Street Food','Spiced potato-filled fried pastry.', 'https://images.unsplash.com/photo-1601050690597-df0568f70950',262,6,24,16,4,2,3,420,'100g','Potato, flour, peas, spices, oil'],
    ['Sugary Soda','Beverages','Carbonated sweetened soft drink.', 'https://images.unsplash.com/photo-1624517452488-04869289c4ca',41,0,10.6,0,0,10.6,0,3,'100ml','Carbonated water, sugar, flavoring'],
    ['Roasted Makhana','Healthy Snacks','Light, crunchy foxnuts roasted with mild seasoning.', 'https://images.unsplash.com/photo-1599599810694-b5b37304c041',356,9.7,76,0.1,0,0,14,5,'100g','Foxnuts, minimal oil, spices'],
    ['Roasted Chana','Healthy Snacks','Crunchy roasted chickpeas packed with plant protein.', 'https://images.unsplash.com/photo-1601058268499-e52658b8bb88',390,20,60,6,1,4,17,38,'100g','Chickpeas, salt'],
    ['Baked Soya Crisps','Packaged Snacks','Protein-rich baked soy snack with a crisp texture.', 'https://images.unsplash.com/photo-1599490659213-e2b9527bd087',420,24,44,16,2,3,8,420,'100g','Soy flour, sunflower oil, seasonings'],
    ['Greek Yogurt & Fruit','Healthy Snacks','Creamy yogurt paired with fresh fruit.', 'https://images.unsplash.com/photo-1488477181946-6428a0291777',95,9,12,2,1.2,8,1.5,36,'100g','Greek yogurt, berries'],
    ['Fruit Chaat','Street Food','Fresh fruit tossed with herbs and mild seasoning.', 'https://images.unsplash.com/photo-1540420773420-3366772f4999',65,1.5,14,0.3,0.1,10,3,40,'100g','Seasonal fruit, lemon, chaat masala'],
    ['Cold Coffee','Beverages','Coffee with milk and a sweetened flavor profile.', 'https://images.unsplash.com/photo-1461023058943-07fcbe16d735',72,2.5,9,3,1.8,8,0.5,45,'100ml','Coffee, milk, sugar'],
    ['Apple','Healthy Snacks','Whole fresh apple with skin.', 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6',52,0.3,14,0.2,0.1,10.4,2.4,1,'100g','Apple'],
    ['Popcorn','Packaged Snacks','Plain air-popped corn kernels.', 'https://images.unsplash.com/photo-1585647347483-22b66260dfff',387,12,78,4.5,0.7,0.9,15,240,'100g','Corn, oil, salt']
  ]
  const insert = db.prepare(`INSERT INTO snacks
    (name,category,description,image_url,calories,protein,carbohydrates,total_fat,saturated_fat,sugar,fiber,sodium,serving_size,ingredients)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
  db.exec('BEGIN')
  snacks.forEach(s => insert.run(...s))
  db.exec('COMMIT')

  const hackCount = db.prepare('SELECT COUNT(*) AS count FROM snack_hacks').get() as { count: number }
  if (!hackCount.count) {
    const hacks = [
      ['Peanut Banana Bites','https://images.unsplash.com/photo-1570197571499-166b36435e9f','Banana, peanut butter','Slice banana and add small spoonfuls of peanut butter.','5','No-cook and made from easy hostel staples'],
      ['Masala Makhana Cup','https://images.unsplash.com/photo-1599599810694-b5b37304c041','Makhana, lemon, chaat masala','Toss makhana with lemon and chaat masala.','3','Low-cost crunch without an oven'],
      ['Overnight Yogurt Jar','https://images.unsplash.com/photo-1488477181946-6428a0291777','Yogurt, oats, fruit','Mix ingredients in a jar and refrigerate overnight.','5','Minimal prep; easy grab-and-go breakfast'],
      ['Quick Fruit Chaat','https://images.unsplash.com/photo-1540420773420-3366772f4999','Apple, banana, lemon, chaat masala','Chop fruit and toss with lemon and seasoning.','7','No-cook, colorful, and flexible'],
      ['Chana Salad','https://images.unsplash.com/photo-1512621776951-a57141f2eefd','Canned chickpeas, cucumber, lemon','Drain chickpeas and mix with chopped cucumber and lemon.','8','Protein-rich and ready in minutes']
    ]
    const insertHack = db.prepare(`INSERT INTO snack_hacks(name,image_url,ingredients,preparation,minutes,convenience) VALUES (?,?,?,?,?,?)`)
    db.exec('BEGIN')
    hacks.forEach(h => insertHack.run(...h))
    db.exec('COMMIT')
  }
  for (let day = 1; day <= 7; day++) {
    db.prepare('INSERT OR IGNORE INTO challenge_progress(day,completed) VALUES (?,0)').run(day)
  }
}
