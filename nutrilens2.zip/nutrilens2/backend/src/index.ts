import express, { Request, Response, NextFunction } from 'express'
import cors from 'cors'
import { db } from './database'
import { seedDatabase } from './seed'
import { gradeSnack, Snack } from './grading'

seedDatabase()

const app = express()
app.use(cors())
app.use(express.json())

const withGrade = (snack: Snack) => ({ ...snack, ...gradeSnack(snack) })

app.get('/api/snacks', (req, res) => {
  const { category, sort } = req.query
  let sql = 'SELECT * FROM snacks'
  const params: unknown[] = []
  if (category && category !== 'All Snacks') {
    sql += ' WHERE category = ?'
    params.push(category)
  }
  if (sort === 'calories') sql += ' ORDER BY calories ASC'
  else if (sort === 'protein') sql += ' ORDER BY protein DESC'
  else if (sort === 'health') sql += ' ORDER BY (sugar + saturated_fat + sodium / 20 - protein - fiber) ASC'
  else sql += ' ORDER BY name ASC'
  const rows = db.prepare(sql).all(...params.map(value => String(value))) as Snack[]
  res.json(rows.map(withGrade))
})

app.get('/api/snacks/search', (req, res) => {
  const q = String(req.query.q || '').trim()
  if (!q) return res.json([])
  const rows = db.prepare('SELECT * FROM snacks WHERE lower(name) LIKE lower(?) ORDER BY name').all(`%${q}%`) as Snack[]
  res.json(rows.map(withGrade))
})

app.get('/api/snacks/categories', (_req, res) => {
  const rows = db.prepare('SELECT DISTINCT category FROM snacks ORDER BY category').all() as { category: string }[]
  res.json(rows.map(row => row.category))
})

app.get('/api/snacks/:id', (req, res) => {
  const snack = db.prepare('SELECT * FROM snacks WHERE id = ?').get(req.params.id) as Snack | undefined
  if (!snack) return res.status(404).json({ message: 'Snack not found' })
  res.json(withGrade(snack))
})

app.get('/api/nutrition/compare/:id1/:id2', (req, res) => {
  const first = db.prepare('SELECT * FROM snacks WHERE id = ?').get(req.params.id1) as Snack | undefined
  const second = db.prepare('SELECT * FROM snacks WHERE id = ?').get(req.params.id2) as Snack | undefined
  if (!first || !second) return res.status(404).json({ message: 'One or both snacks were not found' })
  res.json({ original: withGrade(first), alternative: withGrade(second) })
})

app.get('/api/nutrition/:snackId', (req, res) => {
  const snack = db.prepare('SELECT * FROM snacks WHERE id = ?').get(req.params.snackId) as Snack | undefined
  if (!snack) return res.status(404).json({ message: 'Snack not found' })
  res.json(withGrade(snack))
})

app.get('/api/swaps/:snackId', (req, res, next) => {
  if (!/^\d+$/.test(req.params.snackId)) return next()
  const snack = db.prepare('SELECT * FROM snacks WHERE id = ?').get(req.params.snackId) as Snack | undefined
  if (!snack) return res.status(404).json({ message: 'Snack not found' })
  const rows = db.prepare('SELECT * FROM snacks WHERE id != ?').all(req.params.snackId) as Snack[]
  const alternatives = rows
    .filter(item => item.category === 'Healthy Snacks' ||
      (snack.category === 'Beverages' && item.category === 'Beverages') ||
      (snack.category === 'Sweet Snacks' && item.category === 'Sweet Snacks'))
    .sort((a, b) => a.calories - b.calories)
    .slice(0, 3)
  res.json(alternatives.map(item => ({
    ...withGrade(item),
    differences: {
      calories: item.calories - snack.calories,
      sugar: item.sugar - snack.sugar,
      sodium: item.sodium - snack.sodium,
      protein: item.protein - snack.protein
    },
    benefit: `${item.protein >= snack.protein ? 'More protein' : 'A lighter profile'}, ${item.sugar < snack.sugar ? 'less sugar' : 'a similar sweet profile'}, and ${item.sodium < snack.sodium ? 'less sodium' : 'a savory match'}`
  })))
})

app.get('/api/swaps/logs', (_req, res) => {
  const rows = db.prepare(`
    SELECT l.id,l.original_snack_id,l.alternative_snack_id,l.created_at,
      o.name AS original_name,a.name AS alternative_name,
      o.calories AS original_calories,a.calories AS alternative_calories,
      o.sugar AS original_sugar,a.sugar AS alternative_sugar,
      o.sodium AS original_sodium,a.sodium AS alternative_sodium,
      o.protein AS original_protein,a.protein AS alternative_protein
    FROM swap_logs l
    JOIN snacks o ON o.id=l.original_snack_id
    JOIN snacks a ON a.id=l.alternative_snack_id
    ORDER BY l.created_at DESC
  `).all()
  res.json(rows)
})

app.post('/api/swaps/logs', (req, res) => {
  const original = Number(req.body.original_snack_id)
  const alternative = Number(req.body.alternative_snack_id)
  if (!Number.isInteger(original) || !Number.isInteger(alternative)) {
    return res.status(400).json({ message: 'Both snack IDs are required' })
  }
  if (!db.prepare('SELECT id FROM snacks WHERE id=?').get(original) ||
      !db.prepare('SELECT id FROM snacks WHERE id=?').get(alternative)) {
    return res.status(400).json({ message: 'One or both snack IDs are invalid' })
  }
  const result = db.prepare('INSERT INTO swap_logs(original_snack_id,alternative_snack_id) VALUES (?,?)').run(original, alternative)
  res.status(201).json({ id: result.lastInsertRowid, message: 'Swap logged' })
})

app.delete('/api/swaps/logs/:id', (req, res) => {
  const result = db.prepare('DELETE FROM swap_logs WHERE id=?').run(req.params.id)
  if (!result.changes) return res.status(404).json({ message: 'Swap log not found' })
  res.status(204).send()
})

app.get('/api/swaps/stats', (_req, res) => {
  const rows = db.prepare(`
    SELECT l.created_at,o.calories original_calories,a.calories alternative_calories,
      o.sugar original_sugar,a.sugar alternative_sugar,
      o.sodium original_sodium,a.sodium alternative_sodium,
      o.protein original_protein,a.protein alternative_protein
    FROM swap_logs l
    JOIN snacks o ON o.id=l.original_snack_id
    JOIN snacks a ON a.id=l.alternative_snack_id
  `).all() as any[]
  const stats = rows.reduce((sum, row) => ({
    calories: sum.calories + (row.original_calories - row.alternative_calories),
    sugar: sum.sugar + (row.original_sugar - row.alternative_sugar),
    sodium: sum.sodium + (row.original_sodium - row.alternative_sodium),
    protein: sum.protein + (row.alternative_protein - row.original_protein)
  }), { calories: 0, sugar: 0, sodium: 0, protein: 0 })
  res.json({ total: rows.length, ...stats, activity: rows })
})

app.get('/api/challenges', (_req, res) => {
  res.json([
    'Try a naturally sweet fruit swap',
    'Choose a roasted savory snack',
    'Swap a sugary drink for water or unsweetened tea',
    'Add one protein-rich snack',
    'Choose a whole-food snack',
    'Try a low-sodium crunch',
    'Celebrate a full week of mindful swaps'
  ].map((title, i) => ({ day: i + 1, title })))
})

app.get('/api/challenges/progress', (_req, res) => {
  res.json(db.prepare('SELECT day,completed FROM challenge_progress ORDER BY day').all())
})

app.post('/api/challenges/progress', (req, res) => {
  const day = Number(req.body.day)
  if (!Number.isInteger(day) || day < 1 || day > 7) {
    return res.status(400).json({ message: 'Day must be a number from 1 to 7' })
  }
  const completed = req.body.completed ? 1 : 0
  db.prepare('UPDATE challenge_progress SET completed=? WHERE day=?').run(completed, day)
  res.json(db.prepare('SELECT day,completed FROM challenge_progress WHERE day=?').get(day))
})

app.get('/api/snack-hacks', (_req, res) => {
  res.json(db.prepare('SELECT * FROM snack_hacks').all())
})

app.use((req, res) => res.status(404).json({ message: `Route not found: ${req.method} ${req.path}` }))
app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
  console.error(err)
  res.status(500).json({ message: 'Internal server error' })
})

const port = Number(process.env.PORT || 4000)
app.listen(port, () => console.log(`NutriLens API listening on http://localhost:${port}`))
