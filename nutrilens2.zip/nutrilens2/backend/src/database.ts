import { DatabaseSync } from 'node:sqlite'
import path from 'node:path'

export const db = new DatabaseSync(path.join(__dirname, '..', 'nutrilens.sqlite'))

db.exec(`
  CREATE TABLE IF NOT EXISTS snacks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    description TEXT NOT NULL,
    image_url TEXT NOT NULL,
    calories REAL NOT NULL,
    protein REAL NOT NULL,
    carbohydrates REAL NOT NULL,
    total_fat REAL NOT NULL,
    saturated_fat REAL NOT NULL,
    sugar REAL NOT NULL,
    fiber REAL NOT NULL,
    sodium REAL NOT NULL,
    serving_size TEXT NOT NULL,
    ingredients TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS swap_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    original_snack_id INTEGER NOT NULL,
    alternative_snack_id INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(original_snack_id) REFERENCES snacks(id),
    FOREIGN KEY(alternative_snack_id) REFERENCES snacks(id)
  );
  CREATE TABLE IF NOT EXISTS challenge_progress (
    day INTEGER PRIMARY KEY,
    completed INTEGER NOT NULL DEFAULT 0
  );
  CREATE TABLE IF NOT EXISTS snack_hacks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    image_url TEXT NOT NULL,
    ingredients TEXT NOT NULL,
    preparation TEXT NOT NULL,
    minutes INTEGER NOT NULL,
    convenience TEXT NOT NULL
  );
`)
