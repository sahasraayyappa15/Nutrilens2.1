export type Snack = {
  id: number; name: string; category: string; description: string; image_url: string
  calories: number; protein: number; carbohydrates: number; total_fat: number
  saturated_fat: number; sugar: number; fiber: number; sodium: number
  serving_size: string; ingredients: string
}

export function gradeSnack(s: Snack) {
  let points = 0
  if (s.fiber >= 6) points += 2
  else if (s.fiber >= 3) points += 1
  if (s.protein >= 12) points += 2
  else if (s.protein >= 6) points += 1
  if (s.sugar <= 5) points += 2
  else if (s.sugar <= 10) points += 1
  else if (s.sugar >= 20) points -= 2
  if (s.saturated_fat <= 2) points += 2
  else if (s.saturated_fat <= 5) points += 1
  else if (s.saturated_fat >= 10) points -= 2
  if (s.sodium <= 140) points += 2
  else if (s.sodium <= 300) points += 1
  else if (s.sodium >= 500) points -= 2
  if (s.calories <= 150) points += 2
  else if (s.calories <= 300) points += 1
  else if (s.calories >= 500) points -= 2

  const grade = points >= 9 ? 'A' : points >= 6 ? 'B' : points >= 2 ? 'C' : points >= -2 ? 'D' : 'E'
  const reasons = [
    s.fiber >= 3 ? 'Good fiber content' : 'Low fiber',
    s.protein >= 6 ? 'Helpful protein content' : 'Low protein',
    s.sugar <= 10 ? 'Moderate or low sugar' : 'High sugar',
    s.sodium <= 300 ? 'Moderate or low sodium' : 'High sodium',
    s.saturated_fat <= 5 ? 'Moderate or low saturated fat' : 'High saturated fat'
  ]
  return { grade, score: points, reasons }
}
