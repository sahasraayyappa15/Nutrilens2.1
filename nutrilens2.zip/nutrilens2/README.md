# NutriLens – SnackSwap Showdown

NutriLens is a full-stack snack nutrition and swap tracker built with React, Express, TypeScript, and SQLite.

## Run locally

Requirements: Node.js 18 or newer.

```powershell
npm install
npm run install:all
npm run dev
```

- Frontend: http://localhost:5173
- API: http://localhost:4000

The SQLite database is created automatically at `backend/nutrilens.sqlite`.

## Food imagery

Food photos are resolved by exact food name in `frontend/src/foodImages.ts` and rendered through `frontend/src/FoodImage.tsx`. Keep the mapping aligned with the snack and hack names returned by the API; failed or unmapped images use an explicit fallback. Wikimedia Commons entries include their source, credit, and license in the mapping.

## Useful commands

```powershell
npm run build
npm --prefix backend run dev
npm --prefix frontend run dev
```

## Health grades

Grades are calculated locally in the backend using a simple informational score. The score rewards fiber, protein, low sugar, low saturated fat and low sodium, and considers calories. It is not a medical or regulatory grade.
